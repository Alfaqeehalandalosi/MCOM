<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'OWJanDXmYRhOjbmGOrNT7A');
    define('CONSUMER_SECRET', 'ULt2slNoNzyMUlQ2A0mr0EPbgEK41SFOvARs3bQrHs');

    // User Access Token
    define('ACCESS_TOKEN', '2188867490-MzqWxnd6tp6bJCJ7ZZHVkJSO6FEAILVmVSHcA6s');
    define('ACCESS_SECRET', 'XW5zKIwZrUtdX3HKAFN3oRWTRElqBKmEQpHNjqTbScQGj');